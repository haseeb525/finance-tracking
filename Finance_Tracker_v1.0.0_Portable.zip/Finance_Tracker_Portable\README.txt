Finance Tracker - Portable Version
===================================

QUICK START:
Double-click "Launch.bat" and the app will:
1. Check for Visual C++ Redistributable
2. Auto-install if missing
3. Start the application
Done!

FEATURES:
? Fully portable (no installation)
? Auto-installs C++ if needed
? Persistent login
? Local database
? Excel reports
? Google Drive sync
? Dark/Light theme

REQUIREMENTS:
Windows 10/11 (64-bit)
Internet connection (for authentication)
~300 MB disk space

UNINSTALL:
Delete this folder. That's it!

Version: 1.0.0
Built: February 17, 2026

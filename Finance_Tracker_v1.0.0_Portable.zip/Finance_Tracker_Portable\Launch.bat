@echo off
setlocal enabledelayedexpansion
title Finance Tracker Launcher
color 0A
cd /d "%~dp0"
set APP_EXE=finance_tracking.exe
if not exist "%APP_EXE%" (
    echo ERROR: finance_tracking.exe not found!
    pause
    exit /b 1
)
echo Checking Visual C++ Redistributable...
reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64" >nul 2>&1
if %errorlevel% neq 0 (
    echo Visual C++ Redistributable not found!
    echo Downloading and installing...
    if not exist "%TEMP%\FinanceTrackerSetup" mkdir "%TEMP%\FinanceTrackerSetup"
    PowerShell -NoProfile -ExecutionPolicy Bypass -Command ^
        "try { $url = 'https://aka.ms/vs/17/release/vc_redist.x64.exe'; $output = '%TEMP%\FinanceTrackerSetup\vc_redist.x64.exe'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object System.Net.WebClient).DownloadFile($url, $output); } catch { exit 1; }"
    if exist "%TEMP%\FinanceTrackerSetup\vc_redist.x64.exe" (
        "%TEMP%\FinanceTrackerSetup\vc_redist.x64.exe" /install /quiet /norestart
        timeout /t 2 /nobreak
    )
)
start "" "%APP_EXE%"
exit /b 0
